﻿using System;

namespace BE.Bases
{
    public class Owner
    {
        public int IdOwner { get; set; }
        public string Name { get; set; }
        public string Adress { get; set; }
        public string Photo { get; set; }
        public DateTime Birthday { get; set; }
        public string Email { get; set; }
        public string Passord { get; set; }
    }
}
