﻿namespace Domain
{
    public abstract class BaseDomain<T>
    {
        protected T Repositoty { get; set; }
    }
}
